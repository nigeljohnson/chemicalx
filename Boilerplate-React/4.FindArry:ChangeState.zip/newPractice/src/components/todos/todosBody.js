import React from 'react';

export default class TodosBody extends React.Component {


	render() {
		return (

			<tr> swag </tr>
			);
	}
}