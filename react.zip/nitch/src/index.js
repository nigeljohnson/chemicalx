import React from 'react';
import { render } from 'react-dom';

const message = 'hello';
console.log(message);