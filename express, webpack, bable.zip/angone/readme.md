Super MEAN Stack: Angular, Node/Express, Webpack, MongoDB, SASS, Babel/ES6, Bootstrap

npm i -S express

create server.js
	- var express = require('express');
	- var app = express();

set route & response to request to route

	-   app.all('/*', function (req, res) {
			res.send('\
				');
		});

install dependencies

	- npm i -g webpack webpack-dev-server

	- npm i -D webpack webpack-dev-server (Build Tool)

	- npm i -D babel-loader babel-preset-es2015 (ES6)

create webpack.config.js

run app
	- node server & webpack-dev-server