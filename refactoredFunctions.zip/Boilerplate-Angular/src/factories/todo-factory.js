import angular from 'angular';
import _ from 'lodash';

const todoFactory = angular.module('app.todoFactory', [])

.factory('todoFactory', () => {
	// pass in params object, not reference a copy.
	function createTask($scope, params) {

		// When erase input won't erase from table
		params.createHasInput = false;
		// Empty NG-Model after submit
		$scope.createTaskInput = '';

	}

	function updateTask(todo) {
		todo.task = todo.updatedTask;
		todo.isEditing = false;
	}

	function deleteTask($scope, todoToDelete) {
		_.remove($scope.todos, todo => todo.task === todoToDelete.task);
	}

	function watchCreateTaskInput(prams, $scope, val) {

		if (val && !params.createHasInput) {

			$scope.todos.push({ task: val, isCompleted: false });
			params.createHasInput = true;
		} 

		// Now Else statement - if params is true, we're going to update last todos array, "task" value to match input, update "task"
		else if (val && params.createHasInput) {

			//$scope of todos, passing number -> [] which equals length of array(number of todos) minus 1 position to target last item added into array, WHICH is the item you're currenty making. SMART!
			$scope.todos[$scope.todos.length - 1].task = val;
		}

		if(!val && params.createHasInput) {
			$scope.todos.pop();
			params.createHasInput = false;

		}

	}

	return {
		createTask,
		updateTask,
		deleteTask,

		watchCreateTaskInput
	};
});

export default todoFactory;