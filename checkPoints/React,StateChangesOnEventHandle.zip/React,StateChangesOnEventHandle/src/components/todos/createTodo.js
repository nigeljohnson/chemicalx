import React from 'react';

export default class CreateTodo extends React.Component {

	render() {
		return (

			<form>
				<input type="text" placeholder="testing swag"></input>
				<button>Submit</button>
			</form>

			);
	}
}