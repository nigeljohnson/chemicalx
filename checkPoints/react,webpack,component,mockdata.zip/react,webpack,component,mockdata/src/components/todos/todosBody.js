import React from 'react';

export default class TodosBody extends React.Component {
	render() {

		return(

				<div>body here</div>
					
			);
	}
}