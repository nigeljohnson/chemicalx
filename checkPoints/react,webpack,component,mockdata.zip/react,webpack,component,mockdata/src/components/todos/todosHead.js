import React from 'react';

export default class TodosHead extends React.Component {
	render() {

		return(

				<thead>
					<tr>
						<th> Header </th>
						<th> Actions </th>
					</tr>
				</thead>
					
			);
	}
}