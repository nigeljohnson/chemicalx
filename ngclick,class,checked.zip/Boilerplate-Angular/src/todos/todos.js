export default function($scope) {
	$scope.todos = [
	{
		task: 'property',
		isCompleted: true,
	},
	{
		task: 'property',
		isCompleted: true,
	}
	];

	$scope.onCompletedClick = todo => {
		todo.isCompleted = !todo.isCompleted;
	}
}