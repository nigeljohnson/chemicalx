const message = 'hello from index.js';
console.log(message);

import 'css/master.scss';